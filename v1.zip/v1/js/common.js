
// Load Header template
$(function() {
    $('#header').load('templates/header.html');
});
